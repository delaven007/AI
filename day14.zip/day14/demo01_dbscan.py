"""
demo01_dbscan.py  DBSCAN聚类算法
"""
import numpy as np
import sklearn.cluster as sc
import sklearn.metrics as sm
import matplotlib.pyplot as mp

x = np.loadtxt('../ml_data/perf.txt',
	delimiter=',')
print(x.shape)
# 优选最优的DBSCAN模型的半径
eps = np.linspace(0.3, 1.2, 10)
models, scores = [], [] 
for ep in eps:
	model = sc.DBSCAN(eps=ep, min_samples=3)
	model.fit(x)
	pred_y = model.labels_ # 预测结果
	score = sm.silhouette_score(
		x, pred_y, sample_size=len(x), 
		metric='euclidean')
	models.append(model)
	scores.append(score)
# 输出最优模型与最优得分
scores = np.array(scores)
best_index = scores.argmax()
best_eps = eps[best_index] # 最优半径
best_score = scores[best_index] # 最优得分
print(best_eps, '->', best_score)
# 使用最优模型，绘制聚类效果图
best_model = models[best_index]
pred_y = best_model.fit_predict(x)
# 获取核心样本、外周样本、孤立样本
core_mask = np.zeros(pred_y.size, dtype='bool')
core_mask[best_model.core_sample_indices_]=True
# 孤立样本
offset_mask = (pred_y == -1)
# 外周样本
p_mask = ~(core_mask | offset_mask)

# 画图
mp.figure('DBSCAN', facecolor='lightgray')
mp.title('DBSCAN', fontsize=16)
mp.grid(linestyle=':')
# 核心样本
mp.scatter(x[core_mask][:,0], x[core_mask][:,1], 
	s=70, marker='o', c=pred_y[core_mask], cmap='jet', 
	label='core samples')
# 外周样本
mp.scatter(x[p_mask][:,0], x[p_mask][:,1], 
	s=100, marker='o', c=pred_y[p_mask], cmap='jet', 
	label='p samples', alpha=0.5)
# 孤立样本
mp.scatter(x[offset_mask][:,0], x[offset_mask][:,1], 
	s=100, marker='s', c='black', 
	label='offset samples', alpha=0.5)

mp.legend()
mp.show()



