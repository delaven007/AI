"""
demo02_movie.py  电影推荐
"""
import json
import numpy as np

with open('../ml_data/ratings.json', 'r') as f:
	ratings = json.loads(f.read())
# 获取用户列表
users = list(ratings.keys())
# 构建user-user的相似度矩阵
scmat = [] # 相似度矩阵
for user1 in users:
	scrow = [] # 一行
	for user2 in users:
		# 找到u1与u2共同看过的电影
		movies = set()
		for movie in ratings[user1]:
			if movie in ratings[user2]:
				movies.add(movie)
		# 通过两用户对相同电影评分的距离计算相似度
		if len(movies) == 0:
			score = 0
		else:
			# 整理两个用户对相同电影的评分
			rating_vec1 = []
			rating_vec2 = []
			for movie in movies:
				rating_vec1.append(
					ratings[user1][movie])
				rating_vec2.append(
					ratings[user2][movie])
			# 计算相似度
			rating_vec1 = np.array(rating_vec1)
			rating_vec2 = np.array(rating_vec2)
			# score = 1 / (1+np.sqrt(((rating_vec1- \
			# 	rating_vec2)**2).sum()))
			score = np.corrcoef(rating_vec1, 
				rating_vec2)[0,1]
		scrow.append(score)
	scmat.append(scrow)
print(np.round(scmat, 2))

# 按照相似度从高到低排列每个用户的相似用户
scmat = np.array(scmat)
users = np.array(users)
for i, user in enumerate(users):
	sorted_indices = scmat[i].argsort()[::-1]
	sorted_indices = sorted_indices[
		sorted_indices != i]
	# 相似用户名数组
	sim_users = users[sorted_indices]
	# 每个相似用户的相似度得分
	sim_scores = scmat[i][sorted_indices]
	# print(user, sim_users, sim_scores, sep='\n')

	# 找到所有正相关的用户
	positive_mask = sim_scores > 0
	sim_users = sim_users[positive_mask]
	sim_scores = sim_scores[positive_mask]
	# 使用字典，存储为当前用户推荐的电影
	# { 'movie1':[1.0, 2.0], 
	#   'movie2':[2.0, 3.0, 4.0], 
	#   'movie3':[3.0, 4.0, 5.0, 5.0] }
	reco_movies = {}
	for i, sim_user in enumerate(sim_users):
		for movie, score in \
			ratings[sim_user].items():
			# 相似用户看过，但我没看过
			if movie not in ratings[user].keys():
				if movie not in reco_movies:
					reco_movies[movie] = [score]
				else:
					reco_movies[movie].append(score)

	print(user)
	# print(reco_movies)
	# 对reco_movies进行排序，按照电影评分的均值排序
	movie_list = sorted(reco_movies.items(), 
		key=lambda x: np.average(x[1]),
		reverse=True)
	print(movie_list)
